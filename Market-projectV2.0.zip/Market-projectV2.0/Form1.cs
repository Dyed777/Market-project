﻿using System.Data.OleDb;
using System.Windows.Forms;
using System;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Market_projectV2._0
{
    public partial class Вход : Form
    {
        private string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\User\\source\\repos\\Market-projectV2.0\\Market-projectV2.0\\MarketManagment.accdb";

        public Вход()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text;
            string password = textBox2.Text;

            if (LoginUser(username, password))
            {
                MessageBox.Show("Вход выполнен успешно!");
                Просмотр_данных form1 = new Просмотр_данных();
                form1.ShowDialog();
            }
            else
            {
                MessageBox.Show("Неверное имя пользователя или пароль!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text;
            string password = textBox2.Text;

            if (RegisterUser(username, password))
            {
                MessageBox.Show("Регистрация выполнена успешно!");
            }
            else
            {
                MessageBox.Show("Пользователь с таким именем уже существует!");
            }
        }

        private bool LoginUser(string username, string password)
        {
            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT COUNT(*) FROM Пользователи WHERE [Имя пользователя] = @Username AND [Пароль] = @Password";
                using (OleDbCommand command = new OleDbCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);
                    int count = (int)command.ExecuteScalar();
                    return count > 0;
                }
            }
        }

        private bool RegisterUser(string username, string password)
        {
            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                connection.Open();
                string checkQuery = "SELECT COUNT(*) FROM Пользователи WHERE [Имя пользователя] = @Username";
                using (OleDbCommand checkCommand = new OleDbCommand(checkQuery, connection))
                {
                    checkCommand.Parameters.AddWithValue("@Username", username);
                    int count = (int)checkCommand.ExecuteScalar();
                    if (count > 0)
                    {
                        return false; // Пользователь уже существует
                    }
                }

                string insertQuery = "INSERT INTO Пользователи ([Имя пользователя], [Пароль]) VALUES (@Username, @Password)";
                using (OleDbCommand insertCommand = new OleDbCommand(insertQuery, connection))
                {
                    insertCommand.Parameters.AddWithValue("@Username", username);
                    insertCommand.Parameters.AddWithValue("@Password", password);
                    insertCommand.ExecuteNonQuery();
                    return true;
                }
            }
        }

        private void textBox1_MouseEnter(object sender, EventArgs e)
        {
            toolTip1.Show("Введите ваше имя пользователя.", textBox1); // Показать подсказку на 2 секунды
        }

        private void textBox2_MouseEnter(object sender, EventArgs e)
        {
            toolTip1.Show("Введите ваш пароль.", textBox2); // Показать подсказку на 2 секунды
        }
    }
}
