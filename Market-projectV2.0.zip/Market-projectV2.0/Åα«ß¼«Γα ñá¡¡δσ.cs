﻿using System.Data;
using System;
using System.Data.OleDb;
using System.Windows.Forms;

namespace Market_projectV2._0
{
    public partial class Просмотр_данных : Form
    {
        private string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\User\\source\\repos\\Market-projectV2.0\\Market-projectV2.0\\MarketManagment.accdb";

        public Просмотр_данных()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM Товары";
            LoadDataFromQuery(query);
        }

        private void LoadDataFromQuery(string query)
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    connection.Open();

                    using (OleDbCommand command = new OleDbCommand(query, connection))
                    {
                        using (OleDbDataAdapter adapter = new OleDbDataAdapter(command))
                        {
                            DataTable dataTable = new DataTable();
                            adapter.Fill(dataTable);

                            // Предположим, у вас есть DataGridView для отображения данных
                            dataGridView1.DataSource = dataTable;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string query ="SELECT*FROM Заказы";
            LoadDataFromQuery(query);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string query = "SELECT*FROM Склады";
            LoadDataFromQuery(query);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string query = "SELECT*FROM [Сумма товаров на складах]";
            LoadDataFromQuery(query);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count == 0)
            {
                MessageBox.Show("Нет данных для экспорта!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Диалог для выбора формата экспорта
            var result = MessageBox.Show("Выберите формат экспорта:\n\nда - Excel\nНет - PDF",
                                         "Выбор формата",
                                         MessageBoxButtons.YesNoCancel,
                                         MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                // Экспорт в Excel
                ExcelExport excelExport = new ExcelExport();
                excelExport.Export(dataGridView1);
            }
            else if (result == DialogResult.No)
            {
                // Экспорт в PDF
                PdfExport pdfExport = new PdfExport();
                pdfExport.Export(dataGridView1);
            }
            else
            {
                // Пользователь нажал "Отмена"
                MessageBox.Show("Экспорт отменён.", "Отмена", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

    }
}
