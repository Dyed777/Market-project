﻿using System.Windows.Forms;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Element;

namespace Market_projectV2._0
{
    internal class PdfExport
    {
        public void Export(DataGridView dataGridView)
        {
            if (dataGridView.Rows.Count == 0)
            {
                MessageBox.Show("Нет данных для экспорта!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter = "PDF File (*.pdf)|*.pdf",
                FileName = "ExportedData.pdf"
            };

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                using (var pdfWriter = new PdfWriter(saveFileDialog.FileName))
                {
                    var pdfDocument = new PdfDocument(pdfWriter);
                    var document = new Document(pdfDocument);

                    // Создание таблицы
                    var table = new Table(dataGridView.Columns.Count);

                    // Заголовки столбцов
                    foreach (DataGridViewColumn column in dataGridView.Columns)
                    {
                        table.AddHeaderCell(new Cell().Add(new Paragraph(column.HeaderText)));
                    }

                    // Данные строк
                    foreach (DataGridViewRow row in dataGridView.Rows)
                    {
                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            table.AddCell(new Cell().Add(new Paragraph(cell.Value?.ToString() ?? "")));
                        }
                    }

                    document.Add(table);
                    document.Close();
                    MessageBox.Show("Данные успешно экспортированы в PDF!", "Экспорт завершён", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }
    }
}
